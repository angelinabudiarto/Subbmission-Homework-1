SELECT CategoryName,
COUNT(*) AS NumberOfProducts,
ROUND(AVG(UnitPrice), 2) AS AveragePrice,
MIN(UnitPrice) AS MinPrice,
MAX(UnitPrice) AS MaxPrice,
SUM(UnitsOnOrder) AS TotalOrder
FROM Category INNER JOIN Product ON Category.Id = Product.CategoryID
GROUP BY CategoryName HAVING NumberOfProducts>10 ORDER BY CategoryName;