SELECT productname, CompanyName, ContactName
FROM (SELECT productname, MIN(OrderDate), CompanyName, ContactName
FROM (SELECT Id AS pId, ProductName AS productname FROM Product WHERE Discontinued != 0) as discontinued
INNER JOIN OrderDetail on ProductId = pId
INNER JOIN 'Order' on 'Order'.Id = OrderDetail.OrderId
INNER JOIN Customer on CustomerId = Customer.Id
GROUP BY pId)
ORDER BY productname;

