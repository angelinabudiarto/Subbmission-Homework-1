WITH p AS (
SELECT Product.Id, Product.ProductName AS name
FROM Product
INNER JOIN OrderDetail ON Product.id = OrderDetail.ProductId
INNER JOIN 'Order' ON 'Order'.Id = OrderDetail.OrderId
INNER JOIN Customer ON CustomerId = Customer.Id
WHERE DATE(OrderDate) = '2014-12-25' AND CompanyName = 'Queen Cozinha'
GROUP BY Product.id),
c AS (
SELECT row_number() OVER (order by p.id) AS seqnum, p.name AS name
FROM p),
flattened AS (
SELECT seqnum, name AS name
FROM c
WHERE seqnum = 1
UNION all
SELECT c.seqnum, f.name || ', ' || c.name
FROM c JOIN
flattened f
ON c.seqnum = f.seqnum + 1)
SELECT name FROM flattened
ORDER BY seqnum DESC LIMIT 1;